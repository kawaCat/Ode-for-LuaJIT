﻿
//=============================================================================
#include "ode.h"
#include "export-dif.h"
//=============================================================================

// --this .h file include odemath.cpp.
// --from chipmunk src. "chipmunk-ffi.h".

#ifdef _MSC_VER
	#if _MSC_VER >= 1600
		#define MAKE_REF(name) ODE_API decltype(name) *_##name = name
	#else
		#define MAKE_REF(name)
	#endif
	#else
		#define MAKE_REF(name) ODE_API __typeof__(name) *_##name = name
#endif
//=============================================================================

#ifdef __cplusplus
extern "C" {
#endif
//=============================================================================

//odemath.h
// #define dACCESS33(A,i,j) ((A)[(i)*4+(j)])
ODE_API bool _dVALIDVEC3(dVector3 v) { return dVALIDVEC3(v); };
ODE_API bool _dVALIDVEC4(dVector4 v) { return dVALIDVEC4(v); };
ODE_API bool _dVALIDMAT3(dMatrix3 m) { return dVALIDMAT3(m); };
ODE_API bool _dVALIDMAT4(dMatrix4 m) { return dVALIDMAT4(m); };
//=============================================================================

MAKE_REF(dAddVectors3);
MAKE_REF(dSubtractVectors3);
MAKE_REF(dAddScaledVectors3);
MAKE_REF(dScaleVector3);
MAKE_REF(dNegateVector3);
MAKE_REF(dCopyVector3);
MAKE_REF(dCopyScaledVector3);
MAKE_REF(dCopyNegatedVector3);
MAKE_REF(dCopyVector4);
MAKE_REF(dCopyMatrix4x4);
MAKE_REF(dCopyMatrix4x3);
MAKE_REF(dGetMatrixColumn3);
MAKE_REF(dCalcVectorLength3);
MAKE_REF(dCalcVectorLengthSquare3);
MAKE_REF(dCalcPointDepth3);

//MAKE_REF(_dCalcVectorDot3);
//MAKE_REF(dCalcVectorDot3);
ODE_API dReal P_dCalcVectorDot3_(const dReal *a, const dReal *b, unsigned step_a, unsigned step_b) { return _dCalcVectorDot3(a, b, step_a, step_b); };
ODE_API dReal _dCalcVectorDot3_(const dReal *a, const dReal *b) { return _dCalcVectorDot3(a, b, 1, 1); };

MAKE_REF(dCalcVectorDot3_13);
MAKE_REF(dCalcVectorDot3_31);
MAKE_REF(dCalcVectorDot3_33);
MAKE_REF(dCalcVectorDot3_14);
MAKE_REF(dCalcVectorDot3_41);
MAKE_REF(dCalcVectorDot3_44);

//MAKE_REF(_dCalcVectorCross3);
//MAKE_REF(dCalcVectorCross3); // function name confilict ??
ODE_API void P_dCalcVectorCross3(dReal *res, const dReal *a, const dReal *b, unsigned step_res, unsigned step_a, unsigned step_b) { _dCalcVectorCross3(res,a,b,step_res,step_a,step_b);};
ODE_API void _dCalcVectorCross3_(dReal *res, const dReal *a, const dReal *b) { _dCalcVectorCross3(res, a, b, 1, 1, 1); };

MAKE_REF(dCalcVectorCross3_114);
MAKE_REF(dCalcVectorCross3_141);
MAKE_REF(dCalcVectorCross3_144);
MAKE_REF(dCalcVectorCross3_411);
MAKE_REF(dCalcVectorCross3_414);
MAKE_REF(dCalcVectorCross3_441);
MAKE_REF(dCalcVectorCross3_444);

MAKE_REF(dAddVectorCross3);
MAKE_REF(dSubtractVectorCross3);

MAKE_REF(dSetCrossMatrixPlus);
MAKE_REF(dSetCrossMatrixMinus);
MAKE_REF(dCalcPointsDistance3);
MAKE_REF(dMultiplyHelper0_331);
MAKE_REF(dMultiplyHelper1_331);
MAKE_REF(dMultiplyHelper0_133);
MAKE_REF(dMultiplyHelper1_133);

MAKE_REF(dMultiply0_331);
MAKE_REF(dMultiply1_331);
MAKE_REF(dMultiply0_133);
MAKE_REF(dMultiply0_333);
MAKE_REF(dMultiply1_333);
MAKE_REF(dMultiply2_333);
MAKE_REF(dMultiplyAdd0_331);
MAKE_REF(dMultiplyAdd1_331);
MAKE_REF(dMultiplyAdd0_133);
MAKE_REF(dMultiplyAdd0_333);
MAKE_REF(dMultiplyAdd1_333);
MAKE_REF(dMultiplyAdd2_333);
MAKE_REF(dCalcMatrix3Det);

MAKE_REF(dInvertMatrix3);

// common.h define macro.
//=============================================================================
ODE_API dReal _dPAD(int a) { return dPAD(a); };
#if defined(dSINGLE)
//#define REAL(x) (x##f)					/* form a constant */
ODE_API dReal _dRecip(dReal x)              { return (1.0f / (x));};
ODE_API dReal _dSqrt(dReal x)               { return sqrtf(x);};
ODE_API dReal _dRecipSqrt(dReal x)          { return (1.0/sqrtf(x));};
ODE_API dReal _dSin(dReal x)                { return sinf(x);};
ODE_API dReal _dCos(dReal x)                { return cosf(x);};
ODE_API dReal _dFabs(dReal x)               { return fabsf(x);};
ODE_API dReal _dAtan2(dReal y,dReal x)      { return atan2f((y),(x));};
ODE_API dReal _dAcos(dReal x)               { return acosf( x);};
ODE_API dReal _dFMod(dReal a,dReal b)       { return(fmodf((a),(b)));};
ODE_API dReal _dFloor(dReal x)              { return floorf( x);};
ODE_API dReal _dCeil(dReal x)               { return ceil(x);};
ODE_API dReal _dCopySign(dReal a,dReal b)   { return _ode_copysign(a, b);};
ODE_API dReal _dNextAfter(dReal x, dReal y) { return _ode_nextafter(x, y);};
//=============================================================================
#ifdef HAVE___ISNANF
	ODE_API int _dIsNan(dReal x) { return(__isnanf(x)); };
#elif defined(HAVE__ISNANF)
	ODE_API int _dIsNan(dReal x) { return(_isnanf(x)); };
#elif defined(HAVE_ISNANF)
	ODE_API int _dIsNan(dReal x) { return(isnanf(x)); };
#else
	ODE_API int _dIsNan(dReal x) { return(_isnan(x)); };//fallback
#endif
//=============================================================================
#elif defined(dDOUBLE)
// #define REAL(x) (x)
ODE_API dReal _dRecip(dReal x)              { return (1.0 / (x));};
ODE_API dReal _dSqrt(dReal x)               { return sqrt(x);};
ODE_API dReal _dRecipSqrt(dReal x)          { return (1.0/sqrt(x));};
ODE_API dReal _dSin(dReal x)                { return sin(x);};
ODE_API dReal _dCos(dReal x)                { return cos(x);};
ODE_API dReal _dFabs(dReal x)               { return fabs(x);};
ODE_API dReal _dAtan2(dReal y,dReal x)      { return atan2((y),(x));};
ODE_API dReal _dAcos(dReal x)               { return acos( x);};
ODE_API dReal _dFMod(dReal a,dReal b)       { return(fmod((a),(b)));};
ODE_API dReal _dFloor(dReal x)              { return floor( x);};
ODE_API dReal _dCeil(dReal x)               { return ceil(x);};
ODE_API dReal _dCopySign(dReal a,dReal b)   { return _ode_copysign(a, b);};
ODE_API dReal _dNextAfter(dReal x, dReal y) { return _ode_nextafter(x, y);};
//=============================================================================
#ifdef HAVE___ISNAN
#define dIsNan(x) (__isnan(x))
	ODE_API int _dIsNan(dReal x) { return(__isnan(x)); };
#elif defined(HAVE__ISNAN)
	ODE_API int _dIsNan(dReal x) { return(_isnan(x)); };
#elif defined(HAVE_ISNAN)
	ODE_API int _dIsNan(dReal x) { return(isnan(x)); };
#else
	ODE_API int _dIsNan(dReal x) { return(_isnan(x)); };
#endif
#endif
//=============================================================================

#include "misc.h"

// test
typedef struct
{
	FILE* fp;
}FileOBJ;

ODE_API void FileOBJ_Open(FileOBJ* fpo,const char* filePath, const char* fileOpenMode)
{
    fpo->fp = NULL;
	fpo->fp = fopen(filePath, fileOpenMode);
};

ODE_API bool FileOBJ_Close(FileOBJ* fpo)
{
	bool isSuccess = false;
	if (fpo->fp != NULL)
	{
		fclose(fpo->fp);
		isSuccess = true;
	};
	return isSuccess;
};

//=============================================================================
ODE_API void _dTimerReport(const char* filePath,const char* fileOpenMode, int average)
{
	FILE *fp = fopen(filePath, fileOpenMode);
	dTimerReport (fp, average);
	fclose(fp);
};
//=============================================================================
//ODE_API void _dPrintMatrix_(const dReal *A, int n, int m, const char *fmt,const char* filePath,const char* fileOpenMode)
//{
//	FILE *fp = fopen(filePath, fileOpenMode);
//	dPrintMatrix(A, n, m,fmt,fp );
//	fclose(fp);
//};
//=============================================================================
ODE_API void _dWorldExportDIF(dWorldID w,const char* prefix, const char* filePath, const char* FileOpenMode )
{
	FILE *fp = fopen(filePath, FileOpenMode);
	dWorldExportDIF(w, fp, prefix);
	fclose(fp);
};
//=============================================================================

//=============================================================================
#ifdef __cplusplus
};
#endif
//=============================================================================
